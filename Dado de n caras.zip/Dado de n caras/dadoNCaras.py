

import random

class Dado():
    def __main__(self, caras):
        caras = self.caras
    def estableceCaras(self, n):
        if n==0:
            print("No existen dados de 0 caras")
            return None
        muestra = self.caras = random.randint(1, n)
        return muestra
    def ensayos(self,n):
        dado = Dado()
        nombre_archivo = 'archivo.txt'

        for i in range(100000):
            numerillo = dado.estableceCaras(n)
            with open(nombre_archivo, 'a') as archivo:

                archivo.write(f'\t{numerillo}\n')

dadazo = Dado()
dadazo.ensayos(10)
